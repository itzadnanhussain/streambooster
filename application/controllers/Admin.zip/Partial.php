<?php
defined('BASEPATH') or exit('No direct script access allowed');
define('PATH_TO_CERT', APPPATH . 'third_party\twitch-api\curl\cacert.pem');


class Partial extends CI_Controller
{
    ///Get Top Users List
    public function GetTopUsers()
    {
        if ($this->input->is_ajax_request()) {
            extract($_POST);
            $list = getByWhere($table, '*', array(), array('coins', 'DESC'));
            if ($list) {
                ///Success
                $data = array('code' => 'success', 'data' => $list);
                echo json_encode($data);
                die;
            } else {
                ///credential not correct
                $data = array('code' => 'warning', 'message' => 'You Have No Users');
                echo json_encode($data);
                die;
            }
        }
    }

    ///UpdateUserLevel
    public function UpdateUserLevel()
    {
        if ($this->input->is_ajax_request()) {
            $records = getByWhere('users');
            $count = count($records);
            $levels = TotalLevel();
            for ($i = 0; $i < $count; $i++) {
                for ($j = 2; $j <= $levels; $j++) {
                    //level two logic
                    $bonus = 500;
                    if ($records[$i]->watching_coins >= $j * $bonus  && $records[$i]->level == $j - 1) {

                        $total_coins = $records[$i]->coins + (($bonus * $j) - $bonus);
                        updateByWhere('users', array('level' => $j, 'coins' => $total_coins), array('id' => $records[$i]->id));
                        if ($records[$i]->status == 'active') {
                            $_SESSION['user_info']['level'] = $j;
                        }
                        $data = array('code' => 'success', 'message' => 'updated Level');
                        echo json_encode($data);
                        die;
                    }
                }
            }
        }
    }



    ///AdminAssignCoins
    public function AdminAssignCoins()
    {
        if ($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('coins', 'COINS', 'required');
            if ($this->form_validation->run()) {
                extract($_POST);
                $getCoins = getByWhere('users', '*', array('id' => $id));
                if ($getCoins) {
                    $total_coins = $getCoins[0]->coins + $coins;
                    $check = updateByWhere('users', array('coins' => $total_coins), array('id' => $id));
                    if ($check) {
                        ///Success
                        $data = array('code' => 'success', 'message' => 'Coins Has Been Added');
                        echo json_encode($data);
                        die;
                    }
                } else {
                    ///credential not correct
                    $data = array('code' => 'warning', 'message' => 'Record Not Found!');
                    echo json_encode($data);
                    die;
                }
            } else {
                ///validation errors
                $error_array = array();
                foreach ($_POST as $key => $value) {
                    if (form_error($key)) {
                        $error_array[] = array($key, form_error($key, null, null));
                    }
                }
                $data = array('code' => 'error', 'message' => $error_array);
                echo json_encode($data);
                die;
            }
        }
    }


    ///DeleteUserPermenent
    public function DeleteUserPermenent()
    {
        if ($this->input->is_ajax_request()) {
            extract($_POST);
            $check = deleteRecordWhere('users', array('id' => $id));
            if ($check) {

                ///Success
                $data = array('code' => 'success', 'message' => 'Record Has Been Deleted');
                echo json_encode($data);
                die;
            } else {
                ///credential not correct
                $data = array('code' => 'warning', 'message' => 'Somthing Wrong!');
                echo json_encode($data);
                die;
            }
        }
    }


    ///TempararayBanUser
    public function TempararayBanUser()
    {
        if ($this->input->is_ajax_request()) {
            extract($_POST);
            $check = updateByWhere('users', array('status' => 'banned'), array('id' => $id));
            if ($check) {


                ///Success
                $data = array('code' => 'success', 'message' => 'Record Has Been Deleted');
                echo json_encode($data);
                die;
            } else {
                ///credential not correct
                $data = array('code' => 'warning', 'message' => 'Somthing Wrong!');
                echo json_encode($data);
                die;
            }
        }
    }


    ///UnblockUser
    public function UnblockUser()
    {
        if ($this->input->is_ajax_request()) {
            extract($_POST);
            $check = updateByWhere('users', array('status' => 'inactive'), array('id' => $id));
            if ($check) {


                ///Success
                $data = array('code' => 'success', 'message' => 'Record Has Been Deleted');
                echo json_encode($data);
                die;
            } else {
                ///credential not correct
                $data = array('code' => 'warning', 'message' => 'Somthing Wrong!');
                echo json_encode($data);
                die;
            }
        }
    }

    ////PostCoins
    public function PostCoins()
    {
        if ($this->input->is_ajax_request()) {
            extract($_POST);
            $check = getByWhere('users', '*', array('id' => $_SESSION['user_info']['id']));
            if ($check) {
                $total_coins = $check[0]->coins + $coins;
                $total_watching = $check[0]->watching_coins + $coins;
                $update = updateByWhere('users', array('coins' => $total_coins, 'watching_coins' => $total_watching), array('id' => $_SESSION['user_info']['id']));

                if ($update) {

                    ///Success
                    $string = 'You Have Earned ' . $coins;
                    $_SESSION['user_info']['coins'] = $total_coins;
                    $_SESSION['user_info']['watching_coins'] = $total_watching;
                    $data = array('code' => 'success', 'message' => $string);
                    echo json_encode($data);
                    die;
                }
            } else {
                ///credential not correct
                $data = array('code' => 'warning', 'message' => 'Somthing Wroing');
                echo json_encode($data);
                die;
            }
        }
    }


    ////AssignRanksByAdmin
    public function AssignRanksByAdmin()
    {
        if ($this->input->is_ajax_request()) {
            extract($_POST);
            $data['user_id'] = $id;
            $data['ranks'] = $ranks;
            $data['promotion_status'] = $promotion_status;
            if ($ranks == "Virtual Coins") {
                $data['assign_coins'] = $assign_coins;
            }
            $where = array('user_id' => $id, 'ranks' => $ranks);
            $check = getByWhere('promotion', '*', $where);
            if (empty($check)) {
                $add = addNew('promotion', $data);
                if ($add) {
                    ///Success
                    $data = array('code' => 'success', 'message' => 'Assign Ranks');
                    echo json_encode($data);
                    die;
                }
            } else {
                ///credential not correct
                $data = array('code' => 'warning', 'message' => 'Record Already Exists!');
                echo json_encode($data);
                die;
            }
        }
    }


    ////WatchPageList
    public function WatchPageList()
    {

        if ($this->input->is_ajax_request()) {
            extract($_POST);


            $records = array();
            if ($check == 1) {
                ////Joins
                $tableSelect = "tb1.*, tb2.*";
                $tableInfo = "promotion tb1, users tb2-tb2.id=tb1.user_id-left";
                $records = getByWhere($tableInfo, $tableSelect, array('status' => 'active', 'user_id !=' => $_SESSION['user_info']['id'], 'ranks' => 'Displayed ON Watch Page'), array('invested_coins', 'DESC'));
            }

            if ($check == 0) {
                $records = getByWhere('users', '*', array('username' => $username));
            }

            if ($records) {
                ///Success
                $data = array('code' => 'success', 'records' => $records);
                echo json_encode($data);
                die;
            } else {
                ///credential not correct
                $data = array('code' => 'warning', 'message' => 'Record Not Found!');
                echo json_encode($data);
                die;
            }
        }
    }


    ///LevelUpdateByAdmin
    public function LevelUpdateByAdmin()
    {
        if ($this->input->is_ajax_request()) {
            extract($_POST);
            $count = TotalLevel();
            for ($i = 1; $i <= $count; $i++) {
                if ($i == $level) {
                    $update = updateByWhere('users', array('level' => $level), array('id' => $id));
                    if ($update) {
                        ///Success
                        $data = array('code' => 'success', 'message' => "level change done");
                        echo json_encode($data);
                        die;
                    }
                }
            }
        }
    }


    ////UpdateCommentStatus
    public function UpdateCommentStatus()
    {
        if ($this->input->is_ajax_request()) {
            extract($_POST);
            $check = getByWhere('comments', '*', array('comment_id' => $id, 'status' => $status));
            if ($check) {
                if ($status == "Pending") {
                    $update = updateByWhere('comments', array('status' => 'Active'), array('comment_id' => $id));
                }

                if ($status == "Active") {
                    $update = updateByWhere('comments', array('status' => 'Pending'), array('comment_id' => $id));
                }

                if ($update) {
                    ///Success
                    $data = array('code' => 'success', 'message' => 'Status Has Been Updated');
                    echo json_encode($data);
                    die;
                }
            } else {
                ///credential not correct
                $data = array('code' => 'warning', 'message' => 'Record Not Found!');
                echo json_encode($data);
                die;
            }
        }
    }


    ///GetTotalFollowers
    public function GetTotalFollowers()
    {
        if ($this->input->is_ajax_request()) {
            extract($_POST);
            $users = getByWhere($table);
            $count = count($users);

            for ($i = 0; $i < $count; $i++) {
                $data = array();
                $data = $this->callApiForGetTotalFollowers($users[$i]->twitch_user_id, $users[$i]->twitch_access_token);
                updateByWhere('users', array('followers' => $data->total), array('id' => $users[$i]->id));

            }

            ///Success
            $data = array('code' => 'success', 'message' => 'Followers count Update');
            echo json_encode($data);
            die;
        }
    }


    ///CreatNewFollower
    public function CreateNewFollower()
    {
        if ($this->input->is_ajax_request()) {
            extract($_POST);
           // $to_id="173366421";
            $check = $this->CheckFollowingStatus($to_id);
             

            if ($check->total == 0) {
                
                $response = $this->CallApiToCreateFollower($to_id); 
                if($response==1)
                {
                    ///Success
                    $data=array('code'=>'success','message'=>' Now You Are Following!');
                    echo json_encode($data);
                    die;
                }

                if($response==0)
                {
                    ///Success
                    $data=array('code'=>'success','message'=>'Something Wrong--');
                    echo json_encode($data);
                    die;
                }
               
            } 

            if($check->total == 1)
            {
                
                ///credential not correct
                $data=array('code'=>'warning','message'=>'You already followed');
                echo json_encode($data);
                die;
            }
        }
    }


    ///UserLogout
    public function UserLogout()
    {
        session_destroy();
        redirect('welcome');
    }



    ///
    public function callApiForGetTotalFollowers($to_id, $token)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.twitch.tv/helix/users/follows?to_id=' . $to_id . '',
            //CURLOPT_URL => 'https://api.twitch.tv/helix/users/follows?from_id=618295746&to_id=173366421',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Client-Id: us3vpywudnrnfpyri061w26qe0q8oq',
                'Authorization: Bearer ' . $token . ''
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        $data = json_decode($response);
        return $data;
    }

    ///CheckFollowingStatus
    public function CheckFollowingStatus($to_id)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
            //  CURLOPT_URL => 'https://api.twitch.tv/helix/users/follows?to_id=' . $to_id . '',
            CURLOPT_URL => 'https://api.twitch.tv/helix/users/follows?from_id=' . $_SESSION['user_info']['twitch_user_id'] . '&to_id=' . $to_id . '',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Client-Id: us3vpywudnrnfpyri061w26qe0q8oq',
                'Authorization: Bearer ' . $_SESSION['user_info']['twitch_access_token'] . ''
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        $data = json_decode($response);
        return $data;
    }


    ///CallApiToCreateFollower
    public function CallApiToCreateFollower($to_id)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.twitch.tv/helix/users/follows',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => 'from_id=' . $_SESSION['user_info']['twitch_user_id'] . '&to_id=' . $to_id . '',
            CURLOPT_HTTPHEADER => array(
                'Client-Id: us3vpywudnrnfpyri061w26qe0q8oq',
                'Authorization: Bearer ' . $_SESSION['user_info']['twitch_access_token'] . '',
                'Content-Type: application/x-www-form-urlencoded'
            ),
        ));

        $data = curl_exec($curl);

        if (empty($data) OR (curl_getinfo($curl, CURLINFO_HTTP_CODE == 404))) {
           
            // some kind of an error happened
            die(curl_error($curl));
            curl_close($curl); 
            $data = 0;
            return $data;
        } else {
            // everything  is ok
            $data = 1;
            return $data;

        }
    }
}
