<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Welcome extends CI_Controller
{
    ///Welcome View
    public function index()
    {

        $title = 'Dashboard';
        $page = "welcome";
        ////Joins
        $tableSelect = "tb1.*, tb2.*";
        $tableInfo = "promotion tb1, users tb2-tb2.id=tb1.user_id-left";
        if(isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in'] == true)
        {
            $data['records'] = getByWhere($tableInfo, $tableSelect, array('status' => 'active', 'user_id !=' => $_SESSION['user_info']['id'], 'ranks' => 'Displayed ON Watch Page'), array('invested_coins', 'DESC'));


        }
        else
        {

            $data['records'] = getByWhere($tableInfo, $tableSelect, array('status' => 'active', 'ranks' => 'Displayed ON Watch Page'), array('invested_coins', 'DESC'));
        }
         

        ThemeView($page, $data, $title);
    }


    ///UserRating View
    public function UserRating()
    {
        $title = 'User Rating';
        $page = "userRating";
        $data['records'] = getByWhere('users');
        ThemeView($page, $data, $title);
    }


    ///UserLogin View
    public function UserLogin()
    {
        $title = 'User Rating';
        $page = "userLogin";
        $data = array();
        $this->load->view($page, $data, $title);
    }


    ///UserAuth View
    public function UserAuth()
    {
        $title = 'UserAuth';
        $page = "userAuth";
        $data = array();
        $this->load->view($page, $data, $title);
    }


    ///TopGames View
    public function TopGames()
    {
        $title = 'Top Games';
        $page = "topGames";
        $data = array();
        ThemeView($page, $data, $title);
    }


    ///AboutUs View
    public function AboutUs()
    {
        $title = 'About Us';
        $page = "aboutUs";
        $data = array();
        ThemeView($page, $data, $title);
    }


    ///NewsUpdates View
    public function NewsUpdates()
    {
        $title = 'News Updates';
        $page = "newsUpdate";
        $data = array();
        ThemeView($page, $data, $title);
    }


    ///Articles View
    public function Articles()
    {
        $title = 'Articles';
        $page = "articles";
        $data = array();
        ThemeView($page, $data, $title);
    }


    ///Articles View
    public function ReferencePage()
    {
        redirect('welcome');
    }
}
