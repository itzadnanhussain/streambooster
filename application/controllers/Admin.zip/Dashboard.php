<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Dashboard extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        if (!isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in'] != true) {
            redirect('login/user');
        }
    }

    ///*********************************table names**************************///
    // $promotion_table="promotion";
    // $logs_table="activity_logs";


    ///Welcome View
    public function index()
    {

        $title = 'Dashboard';
        $page = "welcome";
        $data = array();
        ThemeView($page, $data, $title);
    }


    ///LoadPromotionPage
    public function PromotionPage()
    {
        if ($this->input->is_ajax_request()) {

            $this->form_validation->set_rules('invested_coins', 'Invest Coins', 'required');
            if ($this->form_validation->run()) {
                ///table names
                $promotion_table = "promotion";
                $logs_table = "activity_logs";


                extract($_POST);
                $data['user_id'] = $_SESSION['user_info']['id'];
                ///ranks Displayed ON Watch Page
                if ($ranks == "Displayed ON Watch Page") {
                    //check coins
                    if ($_SESSION['user_info']['coins'] >= 0 && $invested_coins <= $_SESSION['user_info']['coins']) {
                        $total_coins = $_SESSION['user_info']['coins'] - $invested_coins;
                    } else {
                        ///credential not correct
                        $data = array('code' => 'warning', 'message' => 'Sorry You Have Enaugh Coins');
                        echo json_encode($data);
                        die;
                    }
                }

                ///generate random key 
                $data['ranks'] = $ranks;

                $data['invested_coins'] = $invested_coins;
                $data['updated_at'] = date('Y-m-d');


                ////Check Records
                ////Joins
                $tableSelect = "tb1.*, tb2.*";
                $tableInfo = "promotion tb1, users tb2-tb2.id=tb1.user_id-left";
                $check['promotion'] = getByWhere($tableInfo, $tableSelect, array('status' => 'active', 'key_value' => $_SESSION['user_info']['key_value'], 'user_id' => $_SESSION['user_info']['id'], 'ranks' => 'Displayed ON Watch Page'));
                $check['Follow'] = getByWhere($tableInfo, $tableSelect, array('status' => 'active', 'key_value' => $_SESSION['user_info']['key_value'], 'user_id' => $_SESSION['user_info']['id'], 'ranks' => 'Displayed ON Follows Page'));
                if ($check['promotion'] && $ranks == "Displayed ON Watch Page") {
                    ///credential not correct
                    $data = array('code' => 'warning', 'message' => 'Sorry You Have Already Request Send');
                    echo json_encode($data);
                    die;
                }

                if ($check['Follow'] && $ranks == "Displayed ON Follows Page") {
                    ///credential not correct
                    $data = array('code' => 'warning', 'message' => 'Sorry You Have Already Request Send');
                    echo json_encode($data);
                    die;
                }
                ///Post data to database

                $check = addNew($promotion_table, $data);
                if ($check) {
                    ///update session coins 
                    if ($ranks == "Displayed ON Watch Page") {
                        updateByWhere('users', array('coins' => $total_coins), array('id' => $_SESSION['user_info']['id']));
                        $_SESSION['user_info']['coins'] = $total_coins;
                    }
                    ///make activity
                    $data = array();
                    $data['user_id'] = $_SESSION['user_info']['id'];
                    $data['username'] = $_SESSION['user_info']['username'];
                    $data['twitch_id'] = $_SESSION['user_info']['twitch_user_id'];
                    $data['discription'] = 'Invest ' . $invested_coins . ' coins For ' . $ranks;

                    $create_logs = addNew($logs_table, $data);
                    if ($create_logs) {
                        ///Success
                        $data = array('code' => 'success', 'message' => 'You have Done');
                        echo json_encode($data);
                        die;
                    }
                } else {
                    ///credential not correct
                    $data = array('code' => 'warning', 'message' => 'Record Not Found!');
                    echo json_encode($data);
                    die;
                }
            } else {
                ///validation errors
                $error_array = array();
                foreach ($_POST as $key => $value) {
                    if (form_error($key)) {
                        $error_array[] = array($key, form_error($key, null, null));
                    }
                }
                $data = array('code' => 'error', 'message' => $error_array);
                echo json_encode($data);
                die;
            }
        } else {
            $title = 'Promotion Page';
            $page = "dashboard/promotion";
            $data = array();
            ThemeView($page, $data, $title);
        }
    }

    ///WatchPage
    public function WatchPage()
    {
        $title = 'Watch Page';
        $page = "dashboard/watch";
        $data = array();
        ThemeView($page, $data, $title);
    }


    ////WatchSingleUser
    public function WatchSingleUser()
    {
        $title = 'Watch Single Page';
        $page = "dashboard/watchsingle";
        $username=$this->uri->segment(4);
        

        ////Joins
        // $tableSelect = "tb1.*, tb2.*";
        // $tableInfo = "promotion tb1, users tb2-tb2.id=tb1.user_id-left";
        // $data['records'] = getByWhere($tableInfo, $tableSelect, array('status' => 'active', 'user_id !=' =>  $this->uri->segment(4), 'ranks' => 'Displayed ON Watch Page'), array('invested_coins', 'DESC'));
        $data = array();


        ThemeView($page, $data, $title);
    }

    ///FollowPage
    public function FollowPage()
    {
        ////Joins
        $tableSelect = "tb1.*, tb2.*";
        $tableInfo = "promotion tb1, users tb2-tb2.id=tb1.user_id-left";
        $data['records'] = getByWhere($tableInfo, $tableSelect, array('status' => 'active', 'user_id !=' => $_SESSION['user_info']['id'], 'ranks' => 'Displayed ON Follows Page'));

        $title = 'Follows Page';
        $page = "dashboard/follows";
        ThemeView($page, $data, $title);
    }


    ///PartnerPage
    public function PartnerPage()
    {
        $title = 'Partner Page';
        $page = "dashboard/partner";
        $data = array();
        ThemeView($page, $data, $title);
    }


    ///SettingsPage
    public function SettingsPage()
    {
        if ($this->input->post()) {
            $this->form_validation->set_rules('bio', 'BIO', 'required');
            if ($this->form_validation->run()) {
                extract($_POST);
                $check = updateByWhere('users', array('bio' => $bio), array('id' => $_SESSION['user_info']['id']));
                if ($check) {
                    $_SESSION['user_info']['bio'] = $bio;
                    ///Success
                    $data = array('code' => 'success', 'message' => 'Record Has Been Updated');
                    echo json_encode($data);
                    die;
                } else {
                    ///credential not correct
                    $data = array('code' => 'warning', 'message' => 'Something Wrong');
                    echo json_encode($data);
                    die;
                }
            }
        } else {
            $title = 'Settings Page';
            $page = "dashboard/setting";
            $data = array();
            ThemeView($page, $data, $title);
        }
    }


    ///PurchasePage
    public function PurchasePage()
    {
        $title = 'Purchase Page';
        $page = "dashboard/purchase";
        $data = array();
        ThemeView($page, $data, $title);
    }


    ///ProfilePage
    public function ProfilePage()
    {
        if ($this->input->is_ajax_request()) {
            extract($_POST);
            $data['comment_to'] = $comment_to;
            $data['comment'] = $comment;
            $data['user_id'] = $_SESSION['user_info']['id'];
            $data['username'] = $_SESSION['user_info']['username'];

            $check = getByWhere('comments', '*', array('user_id' => $data['user_id'], 'comment_to' => $comment_to, 'status' => 'Pending'));
            if (empty($check)) {
                $add = addNew('comments', $data);
                if ($add) {
                    ///Success
                    $data = array('code' => 'success', 'message' => 'Your Suggestion is Posted To Admin Done');
                    echo json_encode($data);
                    die;
                }
            } else {
                ///credential not correct
                $data = array('code' => 'warning', 'message' => 'Your Are Sending Comment Very Fast');
                echo json_encode($data);
                die;
            }
        } else {
            $title = 'Profile Page';
            $page = "dashboard/profile";
            $username = $this->uri->segment(3);
            $data['records'] = getByWhere('users', '*', array('username' => $username));
            ThemeView($page, $data, $title);
        }
    }

    ///UserLogout
    public function UserLogout()
    {

        deleteRecordWhere('promotion', array('ranks=' => 'Displayed ON Watch Page', 'user_id' => $_SESSION['user_info']['id']));
        deleteRecordWhere('promotion', array('ranks=' => 'Displayed ON Follows Page', 'user_id' => $_SESSION['user_info']['id']));
        $check = updateByWhere('users', array('status' => 'inactive'), array('id' => $_SESSION['user_info']['id']));
        if ($check) {
            session_destroy();
            redirect('welcome');
        }
    }
}
