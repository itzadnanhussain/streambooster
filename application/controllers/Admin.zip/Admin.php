<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Admin extends CI_Controller
{
    ///check login
    function __construct()
    {
        parent::__construct();
        if ($_SESSION['logged_in'] != true) {
            redirect('en/admin/login');
        }
    }

    ///LoadStreamerStatistics
    public function index()
    {
        $title = 'Statistics';
        $data = getByWhere('users');
        $count = count($data);
        $coins = 0;
        for ($i = 0; $i < $count; $i++) {
            $coins = $coins + $data[0]->coins;
        }

        // $today = date('Y-m-d');
        // $newdate =date('Y-m-d', strtotime("-7 days"));

        $data['coins'] = $coins;
        $data['streamers'] = $count;
        $data['last7days'] = getByWhere('users', '*', array('register_here >=' => date('Y-m-d', strtotime("-7 days"))));
        $data['last30days'] = getByWhere('users', '*', array('register_here>=' => date('Y-m-d', strtotime("-30 days"))));

        $page = 'admin/statistics';
        AdminView($page, $data, $title);
    }
    ///dashboard
    // public function index()
    // {
    //     $title = 'Dashboard';
    //     $data = array();
    //     $page = 'admin/dashboard';
    //     AdminView($page, $data, $title);
    // }

    ///LoadStreamerTable
    public function LoadStreamerTable()
    {
        $title = 'streamers';
        $data['records'] = getByWhere('users');
        $page = 'admin/streamer';
        AdminView($page, $data, $title);
    }


    ///LoadUsersTable
    public function LoadUsersTable()
    {
        $title = 'Manage Users';
        $data['records'] = getByWhere('users');
        $page = 'admin/users';
        AdminView($page, $data, $title);
    }

    ///LoadSingleStreamer
    public function LoadSingleStreamer()
    {
        $title = 'Single Streamer';
        $id = $this->uri->segment(4);
        $data['records'] = getByWhere('users', '*', array('id' => $id), array('id', 'ASC'));
        $data['logs'] = getByWhere('activity_logs', '*', array('user_id' => $id));
        $data['comments']= getByWhere('comments','*',array('comment_to'=>$id));
        $page = 'admin/profile';
        AdminView($page, $data, $title);
    }


    ///LoadSingleStreamerRanks
    public function LoadSingleStreamerRanks()
    {
        if ($this->input->is_ajax_request()) {
            extract($_POST);
            $update = updateByWhere('promotion',array('promotion_status'=>$promotion_status), array('user_id' => $user_id, 'promotion_id' => $promotion_id));
            if($update)
            {
                ///Success
                $data=array('code'=>'success','message'=>'Ranks Updated');
                echo json_encode($data);
                die;
            }
            else
            {
                ///credential not correct
                $data=array('code'=>'warning','message'=>'Record Not Found!');
                echo json_encode($data);
                die;
            }
            
        } else {
            $title = 'Single Streamer Ranks De';
            $id = $this->uri->segment(4);
            $data['records'] = getByWhere('promotion', '*', array('user_id' => $id, 'promotion_status != ' => 'Displayed ON Watch Page', 'promotion_status !=' => 'Displayed ON Follows Page'));
            $data['id']=$id;

            $page = 'admin/ranks';
            AdminView($page, $data, $title);
        }
    }



    ///LoadBroadcastStatistics
    public function LoadBroadcastStatistics()
    {
        $title = 'Broadcast Rating';
        $id = $this->uri->segment(4);
        $data['records'] = getByWhere('broadcast_rating', '*', array('user_id' => $id));
        $page = 'admin/broadcast';
        AdminView($page, $data, $title);
    }

    ///logout
    public function logout()
    {
        session_destroy();
        redirect('welcome');
    }
}
