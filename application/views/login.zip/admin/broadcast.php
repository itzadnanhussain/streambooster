<div class="content-wrapper">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Broadcast Rating</h4>
                    <div class="row grid-margin">
                        <div class="col-12">
                            <div class="alert alert-success" role="alert">
                                <strong>Heads up!</strong>Here you can check broadcast rating of streamer.
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                        <div id="broadcasting" style="height: 300px; width: 100%;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>