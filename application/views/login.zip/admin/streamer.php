<div class="content-wrapper">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Streamer List </h4>
                    <div class="row grid-margin">
                        <div class="col-12">
                            <div class="alert alert-success" role="alert">
                                <strong>Heads up!</strong> List of all your registered stremers.
                            </div>
                        </div>
                    </div>
                  
                    <div class="row">
                        <div class="col-12">
                            <div class="table-responsive">
                                <div id="order-listing_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table class="table dataTable no-footer id-table" role="grid" aria-describedby="order-listing_info">
                                                <thead>
                                                    <tr class="bg-primary text-white" role="row">
                                                        <th>User Id</th>
                                                        <th>Username</th>
                                                        <th>Total Coins</th>
                                                        <th>Level</th>
                                                        <th>Twitch Followers</th>
                                                        <th>Registered Since</th>
                                                        <th class="text-center">Details</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php if(isset($records) && !empty($records)) { ?>
                                                        <?php foreach ($records as $key => $value) { ?>
                                                        <tr>
                                                        <td><?php echo $value->id; ?></td>
                                                        <td><?php echo $value->username; ?></td>
                                                        <td><?php echo $value->coins; ?></td>
                                                        <td><?php echo $value->level; ?></td>
                                                        <td>test</td>
                                                        <td>
                                                        <?php echo $value->created_at; ?>
                                                        </td>
                                                        <td class="text-center">
                                                            <button tpye="button" class="btn btn-outline-secondary btn-rounded btn-icon">
                                                                <a href="<?php echo base_url('en/admin/streamer/'.$value->id) ?>">
                                                                <i class="mdi mdi-eye text-primary" style="margin-left: -7px;"></i>
                                                                </a>
                                                            </button>
                                                        </td>
                                                    </tr>
                                                       
                                                    <?php } ?>
                                                   
                                                    <?php    } ?>
                                                 

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>