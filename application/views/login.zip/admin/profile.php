<div class="content-wrapper">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="border-bottom text-center pb-4">
                                <img src="<?php echo (isset($records[0]->userprofile) ? $records[0]->userprofile : 'Nothing') ?>" alt="profile" class="img-lg rounded-circle mb-3">
                                <div class="mb-3">
                                    <h3><?php echo (isset($records[0]->username) ? $records[0]->username : 'Nothing') ?></h3>

                                </div>
                                <p class="w-75 mx-auto mb-3"><?php echo (isset($records[0]->bio) ? $records[0]->bio : 'Nothing') ?></p>
                                <!-- <div class="d-flex justify-content-center">
                                    <button class="btn btn-success mr-1">Hire Me</button>
                                    <button class="btn btn-success">Follow</button>
                                </div> -->
                            </div>

                            <div class="border-bottom py-4">
                                <div class="d-flex mb-3">
                                    <div class="progress progress-md flex-grow">
                                        <div class="progress-bar bg-primary" role="progressbar" aria-valuenow="55" style="width: 55%" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                                <div class="d-flex">
                                    <div class="progress progress-md flex-grow">
                                        <div class="progress-bar bg-success" role="progressbar" aria-valuenow="75" style="width: 75%" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="py-4">
                                <p class="clearfix">
                                    <span class="float-left">
                                        Status
                                    </span>
                                    <span class="float-right text-muted">
                                        <?php echo  (isset($records[0]->status) ? $records[0]->status : 'Nothing' ) ?>
                                    </span>
                                </p>
                              
                                <p class="clearfix">
                                    <span class="float-left">
                                        Brodcasting
                                    </span>
                                    <span class="float-right text-muted">
                                        <a href="<?php echo base_url('en/admin/broadcast/1') ?>">
                                            Check Broadcasting Rate

                                        </a>
                                    </span>
                                </p>
                                <p class="clearfix">
                                    <span class="float-left">
                                        Ranks
                                    </span>
                                    <span class="float-right text-muted">
                                        <a href="<?php echo base_url('en/admin/ranks/1') ?>">
                                            Ranks Management

                                        </a>
                                    </span>
                                </p>

                            </div>
                            <button class="btn btn-primary btn-block mb-2" disabled>Bellow you can perform different opertaions on this profile</button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 mx-auto">
                            <ul class="nav nav-pills nav-pills-custom" id="pills-tab-custom" role="tablist">
                                <!----pills-activity---->
                                <li class="nav-item">
                                    <a class="nav-link active" id="pills-home-tab-custom" data-toggle="pill" href="#pills-activity" role="tab" aria-controls="pills-home" aria-selected="true">
                                        Activity
                                    </a>
                                </li>

                                <!----pills-reference---->
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-contact-tab-custom" data-toggle="pill" href="#pills-reference" role="tab" aria-controls="pills-contact" aria-selected="false">
                                        Refferel
                                    </a>
                                </li>


                                <!----pills-level---->
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-contact-tab-custom" data-toggle="pill" href="#pills-level" role="tab" aria-controls="pills-contact" aria-selected="false">
                                        level System
                                    </a>
                                </li>

                                <!----pills-level---->
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-contact-tab-custom" data-toggle="pill" href="#pills-comments" role="tab" aria-controls="pills-contact" aria-selected="false">
                                        Comments
                                    </a>
                                </li>




                            </ul>
                            <div class="tab-content tab-content-custom-pill" id="pills-tabContent-custom">
                                <!----pills-activity---->
                                <div class="tab-pane fade active show" id="pills-activity" role="tabpanel" aria-labelledby="pills-home-tab-custom">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="card">
                                                <div class="card-body">
                                                    <h4 class="card-title">Activity Logs </h4>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="table-responsive">
                                                                <div id="order-listing_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                                                    <div class="row">
                                                                        <div class="col-sm-12">
                                                                            <div id="id-table_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                                                                <div class="row">
                                                                                    <div class="col-sm-12">
                                                                                        <table class="table dataTable no-footer id-table" role="grid" aria-describedby="id-table_info">
                                                                                            <thead>
                                                                                                <tr class="bg-primary text-white" role="row">
                                                                                                    <th>S.NO</th>
                                                                                                    <th>Activity</th>
                                                                                                    <th>Time</th>
                                                                                                </tr>
                                                                                            </thead>
                                                                                            <tbody>
                                                                                                <?php if (isset($logs) && !empty($logs)) { ?>
                                                                                                    <?php foreach ($logs as $key => $value) { ?>
                                                                                                        <tr>
                                                                                                            <td><?php echo (isset($value->activity_id) ? $value->activity_id : 'Nothing') ?></td>
                                                                                                            <td><?php echo (isset($value->discription) ? $value->discription : 'Nothing') ?></td>
                                                                                                            <td><?php echo (isset($value->created_at) ?  $value->created_at : 'Nothing') ?></td>
                                                                                                        </tr>

                                                                                                    <?php } ?>
                                                                                                <?php } ?>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!----pills-reference---->
                                <div class="tab-pane fade" id="pills-reference" role="tabpanel" aria-labelledby="pills-contact-tab-custom">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="card">
                                                <div class="card-body">
                                                    <h4 class="card-title">Refferel Links </h4>
                                                    <p class="card-description">
                                                        The List Of People which has been registered through his referrel links
                                                    </p>
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="table-responsive">
                                                                <div id="order-listing_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                                                    <div class="row">
                                                                        <div class="col-sm-12">
                                                                            <div id="id-table_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                                                                <div class="row">
                                                                                    <div class="col-sm-12">
                                                                                        <table class="table dataTable no-footer id-table" role="grid" aria-describedby="id-table_info">
                                                                                            <thead>
                                                                                                <tr class="bg-primary text-white" role="row">
                                                                                                    <th>S.NO</th>
                                                                                                    <th>Streamer Name</th>

                                                                                                </tr>
                                                                                            </thead>
                                                                                            <tbody>
                                                                                                <tr role="row" class="odd">
                                                                                                    <td>1</td>
                                                                                                    <td>Test</td>


                                                                                                </tr>
                                                                                            </tbody>
                                                                                        </table>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!----pills-level---->
                                <div class="tab-pane fade" id="pills-level" role="tabpanel" aria-labelledby="pills-contact-tab-custom">
                                    <div class="row">
                                        <div class="col-12 grid-margin stretch-card">
                                            <div class="card">
                                                <div class="card-body">
                                                    <h4 class="card-title">Level Management</h4>
                                                    <form class="submit-form" action="<?php echo base_url('LevelUpdateByAdmin') ?>">
                                                        <div class="form-group">
                                                            <input type="text" class="form-control" value="<?php echo (isset($records[0]->level) ? $records[0]->level : 0) ?>" disabled="">
                                                            <input type="hidden" name="id" value="<?php echo (isset($records[0]->id) ? $records[0]->id : 0) ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="exampleSelectGender">Assign New Level</label>
                                                            <select class="form-control" name="level">
                                                                <option value="1">level 1</option>
                                                                <option value="2">level 2</option>
                                                                <option value="3">level 3</option>
                                                                <option value="4">level 4</option>
                                                                <option value="5">level 5</option>
                                                            </select>
                                                        </div>

                                                        <input type="submit" class="btn btn-primary mr-2" value="Update User Level">
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>


                                <!----pills-level---->
                                <div class="tab-pane fade" id="pills-comments" role="tabpanel" aria-labelledby="pills-contact-tab-custom">
                                    <div class="card">
                                        <div class="card-body">
                                            <h4 class="card-title">Comments List </h4>
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="table-responsive">
                                                        <div id="order-listing_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                                            <div class="row">
                                                                <div class="col-sm-12">
                                                                    <div id="id-table_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                                                                        <div class="row">
                                                                            <div class="col-sm-12">
                                                                                <table class="table dataTable no-footer id-table" role="grid" aria-describedby="id-table_info">
                                                                                    <thead>
                                                                                        <tr class="bg-primary text-white" role="row">
                                                                                            <th>S.NO</th> 
                                                                                            <th>Username</th>
                                                                                            <th>Comments</th>
                                                                                            <th>Status</th>
                                                                                            <th>Date</th>
                                                                                        </tr>
                                                                                    </thead>
                                                                                    <tbody>
                                                                                        <?php if (isset($comments) && !empty($comments)) { ?>
                                                                                            <?php $i = 1; ?>
                                                                                            <?php foreach ($comments as $key => $value) { ?>
                                                                                                <tr>
                                                                                                    <td><?php echo $i ?></td> 
                                                                                                    <td><?php echo (isset($value->username) ? $value->username : '') ?></td>
                                                                                                    <td><?php echo (isset($value->comment) ?  $value->comment : '...') ?></td>
                                                                                                    <?php if ($value->status == "Pending") { ?>
                                                                                                        <td><button class="btn btn-danger" onclick="UpdateCommentStatus('<?php echo $value->comment_id ?>' ,'<?php echo $value->status ?>')">Pending</button></td>
                                                                                                    <?php } else { ?>
                                                                                                        <td><button class="btn btn-success" onclick="UpdateCommentStatus('<?php echo $value->comment_id ?>' ,'<?php echo $value->status ?>')">Active</button></td>

                                                                                                    <?php } ?>
                                                                                                    <td><?php echo (isset($value->updated_at) ?  $value->updated_at : '') ?></td>
                                                                                                </tr>
                                                                                                <?php $i++ ?>

                                                                                            <?php } ?>
                                                                                        <?php } ?>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>