<div class="content-wrapper">
    <div class="row">
        <div class="col-md-12">
            <div class="tab-content tab-transparent-content pb-0">
                <div class="tab-pane fade show active" id="overview" role="tabpanel" aria-labelledby="overview-tab">
                    <div class="row">
                        <div class="col-12 col-sm-6 col-md-6 col-xl-6 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex flex-wrap justify-content-between">
                                        <h4 class="card-title">Total Coins</h4>

                                    </div>
                                    <div id="sales" class="carousel slide dashboard-widget-carousel position-static pt-2" data-ride="carousel">
                                        <div class="carousel-inner">
                                            <div class="carousel-item active">
                                                <div class="d-flex flex-wrap align-items-baseline">
                                                    <h2 class="mr-3"><?php echo (isset($coins) ? $coins : '0 Coins') ?></h2>
                                                </div>
                                                <div class="mb-3">
                                                    <p class="text-muted font-weight-bold text-small">Here All Coins Sums Of <span class=" font-weight-normal text-danger">Streamers</span></p>
                                                </div>

                                            </div>
                                            <div class="carousel-item ">
                                                <div class="d-flex flex-wrap align-items-baseline">
                                                    <h2 class="mr-3"><?php echo (isset($coins) ? $coins : '0 Coins') ?></h2>
                                                </div>
                                                <div class="mb-3">
                                                    <p class="text-muted font-weight-bold text-small">Here All Coins Sums Of <span class=" font-weight-normal text-danger">Streamers</span></p>
                                                </div>

                                            </div>


                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6 col-md-6 col-xl-6 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex flex-wrap justify-content-between">
                                        <h4 class="card-title">Total Money</h4>

                                    </div>
                                    <div id="sales" class="carousel slide dashboard-widget-carousel position-static pt-2" data-ride="carousel">
                                        <div class="carousel-inner">
                                            <div class="carousel-item active">
                                                <div class="d-flex flex-wrap align-items-baseline">
                                                    <h2 class="mr-3">Soon</h2>
                                                </div>
                                                <div class="mb-3">
                                                    <p class="text-muted font-weight-bold text-small">Money Raised Through  <span class=" font-weight-normal text-danger">Payment</span></p>
                                                </div>

                                            </div>
                                            <div class="carousel-item">
                                                <div class="d-flex flex-wrap align-items-baseline">
                                                    <h2 class="mr-3">Soon</h2>
                                                </div>
                                                <div class="mb-3">
                                                    <p class="text-muted font-weight-bold text-small">Money Raised Through  <span class=" font-weight-normal text-danger">Payment</span></p>
                                                </div>

                                            </div>
                                            


                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>




                       

                    </div>

                </div>

            </div>
        </div>
    </div> 
     
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="chartjs-size-monitor">
                        <div class="chartjs-size-monitor-expand">
                            <div class=""></div>
                        </div>
                        <div class="chartjs-size-monitor-shrink">
                            <div class=""></div>
                        </div>
                    </div>
                    <h4 class="card-title">Streamer Statistics</h4>
                    <div id="chartContainer" style="height: 300px; width: 100%;"></div>
                </div>
            </div>
        </div>

    </div>

</div>