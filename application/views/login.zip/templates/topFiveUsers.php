<div class="block-3">
    <div class="block-body">
        <h2>TOP-5 Users</h2>
        <ul class="users-list"> 
        </ul>
    </div>
    <div class="block-footer center">
        <a href="<?php echo base_url('en/users-rating') ?>" class="cool-button cool-button-3">View full users rating</a>
    </div>

</div>