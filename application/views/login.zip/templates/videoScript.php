<script type="text/javascript">
    ///Call All Funstion On Window Load
    $(function() {
        var hrefParts = location.href.split('/');
        if (hrefParts[hrefParts.length - 1] == "watch") {
            WatchPageList(1, null);

        } else {
            var username = hrefParts[hrefParts.length - 1]
            WatchPageList(0, username);

        }

    })







    ///WatchPageList

    function WatchPageList(check,username) {

        $.ajax({
            type: 'POST',
            url: '<?php echo base_url('WatchPageList') ?>',
            data: {
                table: 'promotion',
                check: check,
                username: username,
            },
            dataType: 'html',
            success: function(data) {
                let res = JSON.parse(data);
                switch (res.code) {
                    case 'success':
                        ///For Top User

                        var embed = new Twitch.Embed("twitch-embed", {

                            channel: res.records[0]['username'],
                            layout: "video",
                            autoplay: false,
                            // only needed if your site is also embedded on embed.example.com and othersite.example.com 
                            // parent: ["embed.example.com", "othersite.example.com"]
                        });

                        embed.addEventListener(Twitch.Embed.VIDEO_READY, () => {
                            var player = embed.getPlayer();
                            player.play();
                        });


                        var chat = new Twitch.Embed("chat_embed", {

                            channel: res.records[0]['username'],
                            layout: "chat",
                            video: false,
                        });

                        if (res.records[0] != '') {
                            $('#earn-card').css('display', 'block'); 
                            $('#follow-button-1').append('<a id="twitch-follow-button" onclick="CreateNewFollower(' + res.records[0]['user_id'] + ')" class="ajax-popup cool-button follow-button reduce-opacity"><span></span>Follow</a>');
                            $('#profile-text').html(res.records[0]['bio']);
                        }


                        break;
                    case 'warning':
                        $('#no-stream').css('display', 'block');
                        $('#no-stream').css('height', '350px');

                        break



                }
            },

        });


    }
</script>

<script>
    ///StartEarnig Function
    let hour = 0;
    let minute = 0;
    let seconds = 0;
    let coins = 0;
    let totalSeconds = 0;
    let intervalId = null;

    function StartEarning(status) {
        $('#strEarning').css('display', 'none');
        intervalId = setInterval(function() {
            startTimer(status);
        }, 1000);


        setTimeout(function() {
            $('#strEarning').css('display', 'block');
            $('#strlink').text('Resume Earning');
            if (intervalId) {
                clearInterval(intervalId);

            }

        }, 60000 * 5)



    }

    function startTimer(status) {

        ++totalSeconds;
        hour = Math.floor(totalSeconds / 3600);
        minute = Math.floor((totalSeconds - hour * 3600) / 60);
        seconds = totalSeconds - (hour * 3600 + minute * 60);
        if (seconds == 59) {
            PostCoins(100);

        }

        if (minute) {
            coins = minute * 100;


        }

        if (minute <= 0) {
            coins = 0;

        }






        document.getElementById("hour").innerHTML = hour;
        document.getElementById("minute").innerHTML = minute;
        document.getElementById("seconds").innerHTML = seconds;
        document.getElementById("credits-earned").innerHTML = coins;
    }



    ////Post Coins Into DataBase
    function PostCoins(coins) {
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url('PostCoins') ?>',
            data: {
                coins: coins
            },
            dataType: 'html',
            success: function(data) {
                let res = JSON.parse(data);
                switch (res.code) {
                    case 'success':
                        showSuccessToast(res.message);

                        break;
                    case 'warning':
                        showWarningToast(res.message);
                        break;

                }
            }
        });
    }
</script>

<style>
    #chat_embed>iframe {
        height: 709px !important;
        margin-top: -175px;
    }
</style>