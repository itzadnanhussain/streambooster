<div class="block-3">
    <div class="block-body">
        <h2>New Users</h2>
        <ul class="users-list">
            <li><span class="userpic-container">
                    <div class="user-logo-container small"><a href="/en/user/tonybattalio"><span class="online c-help hidden" title="Broadcast is live"></span><img src="https://static-cdn.jtvnw.net/user-default-pictures-uv/ead5c8b2-a4c9-4724-b1dd-9f00b46cbd3d-profile_image-70x70.png" class="user-logo" alt="tonybattalio" title="tonybattalio"></a></div>
                </span><span class="info-container">
                    <div class="user-name"><a class="medium-opacity" href="/en/user/tonybattalio">tonybattalio</a></div>
                    <div class="user-info"><span class="num">11-21-2020, 02:57 pm</span></div>
                </span></li>
            <li><span class="userpic-container">
                    <div class="user-logo-container small"><a href="/en/user/TheShadowScathe"><span class="online c-help hidden" title="Broadcast is live"></span><img src="https://static-cdn.jtvnw.net/jtv_user_pictures/ca2041ac-5975-424e-acad-9e9de873af57-profile_image-70x70.png" class="user-logo" alt="TheShadowScathe" title="TheShadowScathe"></a></div>
                </span><span class="info-container">
                    <div class="user-name"><a class="medium-opacity" href="/en/user/TheShadowScathe">TheShadowScathe</a></div>
                    <div class="user-info"><span class="num">11-21-2020, 12:32 pm</span></div>
                </span></li>
            <li><span class="userpic-container">
                    <div class="user-logo-container small"><a href="/en/user/RB_EL3TTRIC"><span class="online c-help hidden" title="Broadcast is live"></span><img src="https://static-cdn.jtvnw.net/jtv_user_pictures/2ecd5450-6e6e-4853-9795-25cfca8009c4-profile_image-70x70.png" class="user-logo" alt="RB_EL3TTRIC" title="RB_EL3TTRIC"></a></div>
                </span><span class="info-container">
                    <div class="user-name"><a class="medium-opacity" href="/en/user/RB_EL3TTRIC">RB_EL3TTRIC</a></div>
                    <div class="user-info"><span class="num">11-21-2020, 11:28 am</span></div>
                </span></li>
            <li><span class="userpic-container">
                    <div class="user-logo-container small"><a href="/en/user/shadow_of_darkn"><span class="online c-help hidden" title="Broadcast is live"></span><img src="https://static-cdn.jtvnw.net/jtv_user_pictures/24f6f16a-567b-4bd6-ad43-a3179c2450c1-profile_image-70x70.png" class="user-logo" alt="shadow_of_darkn" title="shadow_of_darkn"></a></div>
                </span><span class="info-container">
                    <div class="user-name"><a class="medium-opacity" href="/en/user/shadow_of_darkn">shadow_of_darkn</a></div>
                    <div class="user-info"><span class="num">11-21-2020, 10:55 am</span></div>
                </span></li>
            <li><span class="userpic-container">
                    <div class="user-logo-container small"><a href="/en/user/okToykko"><span class="online c-help hidden" title="Broadcast is live"></span><img src="https://static-cdn.jtvnw.net/jtv_user_pictures/c934c987-c34b-4b73-b73a-2c8d131d18a8-profile_image-70x70.png" class="user-logo" alt="okToykko" title="okToykko"></a></div>
                </span><span class="info-container">
                    <div class="user-name"><a class="medium-opacity" href="/en/user/okToykko">okToykko</a></div>
                    <div class="user-info"><span class="num">11-21-2020, 10:38 am</span></div>
                </span></li>
            <li><span class="userpic-container">
                    <div class="user-logo-container small"><a href="/en/user/Cade_Daniels"><span class="online c-help hidden" title="Broadcast is live"></span><img src="https://static-cdn.jtvnw.net/jtv_user_pictures/1cf74ba0-576f-436a-9571-894e03fb368a-profile_image-70x70.png" class="user-logo" alt="Cade_Daniels" title="Cade_Daniels"></a></div>
                </span><span class="info-container">
                    <div class="user-name"><a class="medium-opacity" href="/en/user/Cade_Daniels">Cade_Daniels</a></div>
                    <div class="user-info"><span class="num">11-21-2020, 10:16 am</span></div>
                </span></li>
            <li><span class="userpic-container">
                    <div class="user-logo-container small"><a href="/en/user/just__joshy"><span class="online c-help hidden" title="Broadcast is live"></span><img src="https://static-cdn.jtvnw.net/jtv_user_pictures/2afad73d-0171-42ca-8bd6-8b522e249270-profile_image-70x70.png" class="user-logo" alt="just__joshy" title="just__joshy"></a></div>
                </span><span class="info-container">
                    <div class="user-name"><a class="medium-opacity" href="/en/user/just__joshy">just__joshy</a></div>
                    <div class="user-info"><span class="num">11-21-2020, 10:09 am</span></div>
                </span></li>
            <li><span class="userpic-container">
                    <div class="user-logo-container small"><a href="/en/user/drbriefs"><span class="online c-help hidden" title="Broadcast is live"></span><img src="https://static-cdn.jtvnw.net/jtv_user_pictures/fb7c208c-996a-42d8-a7b7-8754684143a2-profile_image-70x70.png" class="user-logo" alt="drbriefs" title="drbriefs"></a></div>
                </span><span class="info-container">
                    <div class="user-name"><a class="medium-opacity" href="/en/user/drbriefs">drbriefs</a></div>
                    <div class="user-info"><span class="num">11-21-2020, 09:00 am</span></div>
                </span></li>
            <li><span class="userpic-container">
                    <div class="user-logo-container small"><a href="/en/user/StockWatchTV"><span class="online c-help hidden" title="Broadcast is live"></span><img src="https://static-cdn.jtvnw.net/jtv_user_pictures/743a35c5-9fb7-448f-8bee-7a45e611d355-profile_image-70x70.png" class="user-logo" alt="StockWatchTV" title="StockWatchTV"></a></div>
                </span><span class="info-container">
                    <div class="user-name"><a class="medium-opacity" href="/en/user/StockWatchTV">StockWatchTV</a></div>
                    <div class="user-info"><span class="num">11-21-2020, 08:37 am</span></div>
                </span></li>
            <li><span class="userpic-container">
                    <div class="user-logo-container small"><a href="/en/user/adnantest"><span class="online c-help hidden" title="Broadcast is live"></span><img src="https://static-cdn.jtvnw.net/user-default-pictures-uv/294c98b5-e34d-42cd-a8f0-140b72fba9b0-profile_image-70x70.png" class="user-logo" alt="adnantest" title="adnantest"></a></div>
                </span><span class="info-container">
                    <div class="user-name"><a class="medium-opacity" href="/en/user/adnantest">adnantest</a></div>
                    <div class="user-info"><span class="num">11-21-2020, 08:25 am</span></div>
                </span></li>
        </ul>
    </div>
    <div class="block-footer center">
        <a href="<?php echo base_url('en/users-rating') ?>" class="cool-button cool-button-3">View all users</a>
    </div>
</div>