<script>
    ///Call All Funstion On Window Load
    $(function() {
        GetTopUserList();
        UpdateUserLevel(); 
        GetTotalFollowers(); 
    })







    ///GetTopUserList
    function GetTopUserList() {
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url('GetTopUsersList') ?>',
            data: {
                table: 'users',
            },
            dataType: 'html',
            success: function(data) {
                let res = JSON.parse(data);
                switch (res.code) {
                    case 'success':
                        let list = '';
                        for (let index = 0; index < res.data.length; index++) {
                            list = list + '<li> <span class="userpic-container"><div class="user-logo-container small"><a href="<?php echo base_url('en/user/') ?>' + res.data[index]['username'] + '"><span class="online c-help hidden" title="Broadcast is live"></span> <img src="' + res.data[index]['userprofile'] + '" class="user-logo"></a></div> </span> <span class="info-container"><div class="user-name"><a class="medium-opacity" href="<?php echo base_url('en/user/') ?>' + res.data[index]['username'] + '">' + res.data[index]['username'] + '</a></div><div class="user-info"><span class="num">' + res.data[index]['coins'] + '</span> Total Coins</div> </span></li>';


                        }
                        $('.users-list').html(list)



                        break;
                    case 'warning':


                }
            }
        });
    }


    ///UpdateUserLevel
    function UpdateUserLevel() {
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url('UpdateUserLevel') ?>',
            data: {
                table: 'users',
            },
            dataType: 'html',
            success: function(data) {
                let res = JSON.parse(data);
                switch (res.code) {
                    case 'success':

                        break;
                    case 'warning':


                }
            }
        });

    }


    


    ///GetTotalFollowers
    function GetTotalFollowers() {
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url('GetTotalFollowers') ?>',
            data: {
                table: 'users',
            },
            dataType: 'html',
            success: function(data) {
                let res = JSON.parse(data);
                switch (res.code) {
                    case 'success':

                        break;
                    case 'warning':


                }
            }
        });

    }


    ///CreateNewFollower
    function CreateNewFollower(id) {
        $.ajax({
            type: 'POST',
            url: '<?php echo base_url('CreateNewFollower') ?>',
            data: {
                to_id: id,
            },
            dataType: 'html',
            success: function(data) {
                let res = JSON.parse(data);
                switch (res.code) {
                    case 'success':
                        showSuccessToast(res.message);

                        break;
                    case 'warning':
                        showWarningToast(res.message);


                }
            }
        });

    }

   



    ///FollowTwitchUser
    function FollowTwitchUser(id) {

        $.ajax({
            type: 'POST',
            url: '<?php echo base_url('FollowToTwitchUser') ?>',
            data: {
                'id': id,
                'status': "Following"
            },
            dataType: 'html',
            success: function(data) {
                let res = JSON.parse(data);
                switch (res.code) {
                    case 'success':
                        showSuccessToast(res.message);
                        setTimeout(function() {
                            window.location.reload();
                        }, 3500)
                        break;
                    case 'warning':
                        showWarningToast(res.message);
                        break;

                }
            }
        });
    }


     
</script>