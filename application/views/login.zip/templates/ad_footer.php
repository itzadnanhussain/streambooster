 <!-- content-wrapper ends -->
 <!-- partial:partials/_footer.html -->
 <div class="footer-wrapper">
   <footer class="footer">
     <div class="d-sm-flex justify-content-center justify-content-sm-between">
       <span class="text-center text-sm-left d-block d-sm-inline-block">Copyright &copy; <?php echo date('Y') ?>. All rights reserved. </span>
     </div>
   </footer>
 </div>
 <!-- partial -->
 <!-- main-panel ends -->
 </div>
 <!-- page-body-wrapper ends -->
 </div>
 </div>
 <!-- container-scroller -->
 <!-- base:js -->
 <script src="<?php echo base_url('assets/admin/') ?>vendors/base/vendor.bundle.base.js"></script>
 <!-- endinject -->
 <!-- Plugin js for this page-->

 <script src="<?php echo base_url('assets/admin/') ?>js/off-canvas.js"></script>
 <script src="<?php echo base_url('assets/admin/') ?>js/hoverable-collapse.js"></script>
 <script src="<?php echo base_url('assets/admin/') ?>js/template.js"></script>
 <script src="<?php echo base_url('assets/admin/') ?>js/settings.js"></script>
 <script src="<?php echo base_url('assets/admin/') ?>js/todolist.js"></script>
 <script src="<?php echo base_url('assets/admin/') ?>vendors/datatables.net/jquery.dataTables.js"></script>
 <script src="<?php echo base_url('assets/admin/') ?>vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
 <script src="<?php echo base_url('assets/admin/') ?>js/dashboard.js"></script>
 <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
 <script src="<?php echo base_url('assets/admin/') ?>vendors/jquery-toast-plugin/jquery.toast.min.js"></script>
 <script src="<?php echo base_url('assets/admin/') ?>js/toastDemo.js"></script>

 <!-- End custom js for this page-->

 <!---Check Script File---->
 <?php
  $this->load->view('templates/ad_scripts');
   

  ?>

 </body>

 </html>