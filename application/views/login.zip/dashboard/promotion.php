 <!----Sec3 Content--->
 <div class="container-fluid mt-15">
     <div class="row">
         <div class="col-md-3 col-xs-12">
             <?php $this->load->view('templates/sideBar') ?>
         </div>
         <div class="col-md-9 col-xs-12">
             <div class="content">
                 <div class="block">
                     <h1>Invest Coins For Getting Top Streams On The List</h1>

                     <!---Invest Coins For Getting Top Streams On The List--->
                     <form class="invest-coins">
                         <input type="hidden" value="Displayed ON Watch Page" name="ranks">
                         <div class="field-comment">Here the streamer can invest the collected coins to be displayed on the WATCH page</div>
                         <div class="placeholder">Account Name:</div>
                         <input type="text" name="username" class="with-comment" value="<?php echo $_SESSION['user_info']['username'] ?>" disabled>
                         <div class="placeholder">You Have Total Coins <span class="credits-icon"></span><?php echo $_SESSION['user_info']['coins'] ?></div>
                         <input name="total-coins" type="text" class="with-comment" value="<?php echo $_SESSION['user_info']['coins'] ?>" disabled>

                         <div class="placeholder">Invest Coins From O to <span class="credits-icon"></span>10,000):</div>
                         <input name="invested_coins" type="number" class="with-comment" value="<?php echo $_SESSION['user_info']['coins'] ?>" min="0" max="<?php echo $_SESSION['user_info']['coins'] ?>">
                         <div class="field-comment">You can set the amount of bounty gold For Getting Top Streams On The List.Your account will be charged the same amount of gold. If you do not want promote your stream on the Stream Booster website, set this parameter to 0.</div>
                          <input type="submit" class="cool-button form-submitter" value="Save changes">
                     </form>
                 </div>


                 <div class="block">
                     <h1>Invest Coins For Follwing</h1>
                     <form class="invest-coins">
                     <input type="hidden" value="Displayed ON Follows Page" name="ranks">
                         <div class="field-comment">Here the streamer can invest the collected coins to be displayed on the Follow Page.</div>
                         <div class="placeholder">Account Name</div>
                         <input type="text" name="username" class="with-comment" value="<?php echo $_SESSION['user_info']['username'] ?>" disabled>
                         <div class="placeholder">You Have Total Coins <span class="credits-icon"></span><?php echo $_SESSION['user_info']['coins'] ?></div>
                         <input name="total-coins" type="text" class="with-comment" value="<?php echo $_SESSION['user_info']['coins'] ?>" disabled>

                         <div class="field-comment">If account name in the service for collecting donations differs from your current name, you can specify it here. Characters [a-z0-9_] are allowed in any layout.</div>

                         <div class="placeholder">Invest Coins From O to <span class="credits-icon"></span>10,000):</div>
                         <input name="invested_coins" type="number" class="with-comment" value="<?php echo $_SESSION['user_info']['coins'] ?>" min="0" max="<?php echo $_SESSION['user_info']['coins'] ?>">
                           <div class="field-comment">You can set the amount of bounty gold for following your channel. The followed user will recieve this bounty and your account will be charged the same amount of gold. If the following is later canceled by the user, all bounty gold will be returned to your account. If you do not want users to follow your channel on the Stream Booster website, set this parameter to 0.</div>
                         <input type="submit" class="cool-button form-submitter" value="Save changes">

                         
                     </form>
                 </div>
             </div>

         </div>

     </div>

 </div>