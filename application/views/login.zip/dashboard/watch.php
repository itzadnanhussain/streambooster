 <!----Sec3 Content--->
 <div class="container-fluid mt-15">
     <div class="row" id="no-stream" style="display: none;">
         <div class="col-sm-12">
         <div class="content">
                 <div class="block">
                     <h1>No Stream Available at this time</h1> 
                 </div>  
             </div>  
         </div> 
     </div>
     <div class="row">
         <div class="col-sm-9 col-lg-9">
             <div class="content watch">
                 <div class="card">
                     <div id="twitch-embed">
                     </div>
                     <div class="card-body" id="earn-card" style="display: none;">
                         <div class="block" id="under-player-panel">
                             <ul id="menu">
                                 <li class="left-side" id="strEarning"> <a class="cool-button youtube-button" id="strlink" onclick="StartEarning('standard')">Start Earning</a> </li>

                                 <li class="left-side"><span id="check-if-user-here-1" class=""><span class="credits-icon"></span><span id="credits-earned" class="c-help" title="Amount of gold earned">0.00</span></span></li>
                                 <li class="left-side"><span id="check-if-user-here-2" class=""><span class="timer-icon"></span><span class="straight-timer c-help" id="watching-duration"><span id="hour">00</span>:<span id="minute">00</span>:<span id="seconds">00</span></span></span></li>
                                 <li class="left-side"><span id="check-if-user-here-3" class=""><span class="credits-icon">
                                             <div class="cool-warning-title box-shadow hidden" id="buffering-stream-warning">
                                                 <div class="tarr"></div>Users with the broadcast viewing page opened in the background are not counted as viewers and do not earn gold when the stream is buffering in Twitch player.
                                             </div>
                                         </span><span class="c-help" title="The rate of gold earning"><span id="credits-per-minute">100</span> per min.</span></span></li>
                                 <li class="right-side"><i class="fas fa-user"></i> <?php echo (isset($records[0]->view_counts) ? $records[0]->view_counts :  0) ?></li>
                                 <li class="right-side"><i class="fas fa-heart"></i> 610</li>
                                 <li class="right-side" id="donate-button-li"><span id="donate-button-span" class=""><a id="donate-button" href="http://www.donationalerts.ru/r/andreynoskoff" target="_blank" class="cool-button cool-button-3">Donate</a></span></li>
                                 <li class="right-side"> <span id="follow-button-1"> </span></li>
                             </ul>


                         </div>


                     </div>

                 </div>

                 <!-- <div class="row">
                     <?php if (isset($records) && !empty($records)) { ?>
                     <?php $count = count($records); ?>
                     <?php for ($i = 1; $i < $count; $i++) { ?>

                         <div class="col-lg-6 col-xs-12 ">
                             <div class="card">
                                 <div id="twitch-embed_<?php echo $i ?>">
                                 </div>
                                 <div class="card-body">
                                     <div class="block" id="under-player-panel">
                                         <div class="block-footer center">

                                             <a href="<?php echo base_url('en/dashboard/watch/' . $records[$i]->id) ?>" class="cool-button twitch-button reduce-opacity"><span></span>Watch the broadcast</a>

                                         </div>

                                     </div>


                                 </div>
                             </div>
                         </div>

                     <?php } ?>

                     <?php } ?>

                 </div> -->
             </div>
         </div>
         <div class="col-sm-3 card" id="chat_embed" style="height: fit-content;">


         </div>
     </div>
     <div class="row">
         <div class="col-sm-9 col-xs-12">
             <h3>About Streamer</h3>
         <blockquote>
             <p class="text-justify" id="profile-text"></p></blockquote>

         </div>
         <div class="col-sm-3 col-xs-12">

         </div>

     </div>
 </div>

 <style>
     .cool-button {
         font-size: 9px !important;
         line-height: 20px !important;
         padding: 0 5px !important;
         height: 20px !important;
     }

     .stretch-card>.card {
         width: 100%;
         min-width: 100%
     }

     .flex {
         -webkit-box-flex: 1;
         -ms-flex: 1 1 auto;
         flex: 1 1 auto;
     }

     @media (max-width:991.98px) {
         .padding {
             padding: 1.5rem
         }
     }

     @media (max-width:767.98px) {
         .padding {
             padding: 1rem
         }
     }

     .padding {
         padding: 3rem
     }

      

     /*card css*/

     .block {
         background: #fff;
         border: #e1e4eb 1px solid;
     }

     ul#menu li {
         display: inline;
         padding-right: 6%;
         margin: 10;
     }

     #menu {
         padding-left: 0 !important;
     }

     #under-player-panel {
         font-size: 11px;
         overflow: hidden;
     }

     .videosize {
         width: 100% !important;
     }

     .card-body {
         padding-left: 3px !important;
         padding-right: 3px !important;
         padding-top: 5px !important;
         padding-bottom: 5px !important;
     }

     .padds {
         padding-left: 0;
         padding-right: 2px;
     }






     .cardset {
         padding-left: 3px;
         padding-right: 3px;
         padding-top: 5px;
     }

     .fa-clock {
         color: gray !important;
     }

     .fa-coins {
         color: gold !important;
     }

     .fa-heart {
         color: gray !important;
     }

     .fa-user {
         color: red !important;
     }

     .paddings {
         padding: 3rem;
     }

     @media only screen and (max-width: 600px) {
         .paddings {
             padding: 0 !important;
         }

        

         #under-player-panel {
             font-size: 9px !important;
         }

         ul#menu li {
             display: inline;
             padding-right: 2%;
         }

         .block {
             padding-left: 5%;
             padding-top: 7%;
         }
     }
 </style>
 <style>
     iframe {
         width: 100% !important;
         height: 450px;

     }

     .card {
         margin-top: 20px;
         margin-bottom: 20px;
         overflow: hidden;
     }
 </style>