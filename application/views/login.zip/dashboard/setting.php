  <!----Sec3 Content--->
  <div class="container-fluid mt-15">
      <div class="row">
          <div class="col-md-3 col-xs-12">
              <?php $this->load->view('templates/sideBar') ?>
          </div>
          <div class="col-md-9 col-xs-12">
              <div class="content">
                  <div class="block">
                      <h1>Update Your Profile</h1>
                      <form class="invest-coins">
                          <div class="placeholder">Write Something about yourself:</div> 
                          <textarea class="with-comment" style="width: 100%;" name="bio" minlength="500" maxlength="5000"></textarea>
                          <div class="field-comment">The minimum number of characters is 500, the maximum is 5,000. This text is moderated before publication. If the text does not pass moderation, the next one can be sent <span class="red">only after 7 days</span>.</div>  
                          <input type="submit" class="cool-button form-submitter" value="Save Changes">
                      </form>
                  </div>
              </div>

          </div>

      </div>

  </div>