  <!----Sec3 Content--->
  <div class="container-fluid mt-15">
      <div class="row">
          <div class="col-md-3 col-xs-12">
              <?php $this->load->view('templates/sideBar') ?>
          </div>
          <div class="col-md-9 col-xs-12">
              <div class="content">
                  <div class="block">
                      <h1>Account Upgrades</h1>
                      <p>Here you can upgrade your account and get additional benefits in Stream Booster system.</p>

                      <div class="row">
                          <div class="col-md-4 col-xs-12">
                              <div class="large-catalog-inner-block block-3">
                                  <div class="block-body">
                                      <h2>Virtual Coins <span class="credits-icon"></span></h2>
                                      <!--<img class="large-catalog-image" src="/i/upgrade-5.png">-->
                                      <p>Here you can buy coins through pyment if your payment successful done then you have recieved coins.</p>
                                  </div>
                                  <div class="block-footer center">
                                      <form action="" method="post" enctype="multipart/form-data">
                                          <input type="hidden" name="upgrade" value="5">
                                          <input type="hidden" name="hash" value="a8fd4da84727be1da629e6bf68151dab">
                                          <input type="hidden" name="upgrade_activation" value="7bo2k72ft31f1lri42kp6c8or0">
                                          <a href="" class="cool-button cool-button-3 form-submitter">Buy Coins</a>
                                          <input type="submit" class="hidden"></form>
                                  </div>

                              </div>

                          </div>
                          <div class="col-md-4 col-xs-12">
                              <div class="large-catalog-inner-block block-3">
                                  <div class="block-body">
                                      <h2>Promoted-Rank <span class="credits-icon"></span></h2>
                                      <!--<img class="large-catalog-image" src="/i/upgrade-5.png">-->
                                      <p>Here you promote your streams buy pyment.if your payment successful done then you have able to promot one stream.</p>
                                  </div>
                                  <div class="block-footer center">
                                      <form action="" method="post" enctype="multipart/form-data">
                                          <input type="hidden" name="upgrade" value="5">
                                          <input type="hidden" name="hash" value="a8fd4da84727be1da629e6bf68151dab">
                                          <input type="hidden" name="upgrade_activation" value="7bo2k72ft31f1lri42kp6c8or0">
                                          <a href="" class="cool-button cool-button-3 form-submitter">Promote Ranks</a>
                                          <input type="submit" class="hidden"></form>
                                  </div>

                              </div>

                          </div>
                          <div class="col-md-4 col-xs-12">
                              <div class="large-catalog-inner-block block-3">
                                  <div class="block-body">
                                      <h2>Double Coins <span class="credits-icon"></span></h2>
                                      <!--<img class="large-catalog-image" src="/i/upgrade-5.png">-->
                                      <p>Here you can get double coins through pyment.Then you have able to get double coins on watching stream.</p>
                                  </div>
                                  <div class="block-footer center">
                                      <form action="" method="post" enctype="multipart/form-data">
                                          <input type="hidden" name="upgrade" value="5">
                                          <input type="hidden" name="hash" value="a8fd4da84727be1da629e6bf68151dab">
                                          <input type="hidden" name="upgrade_activation" value="7bo2k72ft31f1lri42kp6c8or0">
                                          <a href="" class="cool-button cool-button-3 form-submitter">Double Coins</a>
                                          <input type="submit" class="hidden"></form>
                                  </div>

                              </div>

                          </div>

                          <div class="col-md-4 col-xs-12">
                              <div class="large-catalog-inner-block block-3">
                                  <div class="block-body">
                                      <h2>AFK Varification <span class="credits-icon"></span></h2>
                                      <!--<img class="large-catalog-image" src="/i/upgrade-5.png">-->
                                      <p>Here you can get double coins through pyment.Then you have able to get double coins on watching stream.</p>
                                  </div>
                                  <div class="block-footer center">
                                      <form action="" method="post" enctype="multipart/form-data">
                                          <input type="hidden" name="upgrade" value="5">
                                          <input type="hidden" name="hash" value="a8fd4da84727be1da629e6bf68151dab">
                                          <input type="hidden" name="upgrade_activation" value="7bo2k72ft31f1lri42kp6c8or0">
                                          <a href="" class="cool-button cool-button-3 form-submitter">Double Coins</a>
                                          <input type="submit" class="hidden"></form>
                                  </div>

                              </div>

                          </div>
                      </div>


                  </div>
              </div>

          </div>

      </div>

  </div>